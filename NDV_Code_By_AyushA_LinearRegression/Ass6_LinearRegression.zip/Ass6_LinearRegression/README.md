# Assignment 6: Linear Regression for Predicting Salary

## Objective
Use simple linear regression to predict employee salary based on years of experience.

## Project Structure