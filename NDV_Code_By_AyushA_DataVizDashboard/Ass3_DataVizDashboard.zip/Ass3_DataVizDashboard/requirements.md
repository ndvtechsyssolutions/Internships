streamlit
pandas
numpy
matplotlib
seaborn